-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18-Jul-2022 às 13:54
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `neutron`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients`
--

CREATE TABLE `clients` (
  `id_client` int(11) NOT NULL,
  `name_client` varchar(250) NOT NULL,
  `nif_client` int(11) NOT NULL,
  `phone_client` varchar(50) DEFAULT NULL,
  `email_client` varchar(250) DEFAULT NULL,
  `address_client` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clients`
--

INSERT INTO `clients` (`id_client`, `name_client`, `nif_client`, `phone_client`, `email_client`, `address_client`) VALUES
(7, 'teste', 11111, '11111', 'teste', 'teste'),
(13, 'why', 1212, '1222', 'joaodacax@gmail.com', 'teste'),
(14, 'Victor', 555, '909090', 'victor', 'rua pinheiro'),
(15, 'teste', 0, '55555', 'teste@gmail.com', 'portugal'),
(16, 'teste2', 12345, '10043', 'teste2@gmail.com', 'portugal'),
(17, 'Lucas', 4321, '090909', 'lucasedu623@gmail.com', 'portugal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `diagnosis`
--

CREATE TABLE `diagnosis` (
  `id_dg` int(11) NOT NULL,
  `id_wkr` int(11) NOT NULL,
  `id_eqp` int(11) NOT NULL,
  `date_diagnosis_dg` timestamp NOT NULL DEFAULT current_timestamp(),
  `diagnosis_dg` longtext NOT NULL,
  `duration_dg` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `diagnosis`
--

INSERT INTO `diagnosis` (`id_dg`, `id_wkr`, `id_eqp`, `date_diagnosis_dg`, `diagnosis_dg`, `duration_dg`) VALUES
(2, 1, 6, '2022-07-02 17:07:45', 'sad', '2'),
(4, 1, 7, '2022-07-02 18:22:19', 'quebrado', '4'),
(5, 14, 9, '2022-07-02 20:57:42', 'Bateria danificada', '4'),
(6, 1, 8, '2022-07-02 21:04:42', 'ggggg', '4'),
(7, 1, 10, '2022-07-02 21:12:21', 'Nenhum', '6'),
(8, 1, 11, '2022-07-02 21:27:16', 'Placa Quebrada, Fio cortado', '999'),
(9, 1, 12, '2022-07-02 21:47:51', 'teste', '45'),
(10, 1, 13, '2022-07-03 16:28:34', 'teste2', '999'),
(11, 1, 14, '2022-07-03 16:33:07', 'teste3', '4'),
(12, 1, 15, '2022-07-04 00:27:29', 'teste4', '34'),
(13, 1, 16, '2022-07-04 10:25:24', 'teste5', ''),
(14, 1, 17, '2022-07-04 16:05:59', 'teste', '7'),
(15, 1, 18, '2022-07-13 20:39:10', 'teste7', '999'),
(16, 1, 19, '2022-07-17 17:03:31', 'teste8', '6'),
(17, 1, 20, '2022-07-17 17:08:51', 'teste9', '34'),
(18, 1, 21, '2022-07-17 17:14:19', 'teste10', '34'),
(19, 1, 22, '2022-07-17 17:18:21', 'teste11', '999'),
(20, 1, 23, '2022-07-17 17:22:40', 'teste12', '666'),
(21, 1, 25, '2022-07-18 11:35:53', 'desligado', '44'),
(22, 1, 26, '2022-07-18 11:41:07', 'fdfdf', '44'),
(23, 1, 24, '2022-07-18 11:43:25', 'hgjghghj', '44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `equipament`
--

CREATE TABLE `equipament` (
  `id_eqp` int(11) NOT NULL,
  `id_dg` int(11) DEFAULT NULL,
  `id_rp` int(11) DEFAULT NULL,
  `brand_eqp` varchar(250) NOT NULL,
  `model_eqp` varchar(250) DEFAULT NULL,
  `seriesnum_eqp` varchar(250) DEFAULT NULL,
  `observations_eqp` longtext NOT NULL,
  `date_reception_eqp` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_withdraw_eqp` timestamp NOT NULL DEFAULT current_timestamp(),
  `reception_wrk_eqp` int(11) NOT NULL,
  `simptons_eqp` longtext NOT NULL,
  `state_eqp` longtext NOT NULL,
  `finalcost_eqp` varchar(50) DEFAULT NULL,
  `handed_wkr_eqp` int(11) DEFAULT NULL,
  `status_eqp` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `equipament`
--

INSERT INTO `equipament` (`id_eqp`, `id_dg`, `id_rp`, `brand_eqp`, `model_eqp`, `seriesnum_eqp`, `observations_eqp`, `date_reception_eqp`, `date_withdraw_eqp`, `reception_wrk_eqp`, `simptons_eqp`, `state_eqp`, `finalcost_eqp`, `handed_wkr_eqp`, `status_eqp`) VALUES
(6, 2, 0, 'dsfsadf', 'dasfsdafa', 'asdfsadf', 'asdfasfd', '2022-06-22 11:24:16', '0000-00-00 00:00:00', 1, 'asdfsad', 'dfasdf', NULL, 1, 'Concluido'),
(7, 4, 4, 'asdfasf', 'dfasdfasf', 'fasfasd', 'adfsdfasf', '2022-06-22 12:52:27', '0000-00-00 00:00:00', 1, 'asdfsdfas', 'asdfsadf', '67', 1, 'Concluido'),
(8, 6, 3, 'gggg', 'ggggg', 'gggg', 'ggggg', '2022-07-01 20:17:18', '0000-00-00 00:00:00', 1, 'ggggg', 'gggg', '34', 1, 'Concluido'),
(9, 5, 2, 'Lenovo', 'NoteBook', 'MD5T4', 'Tela Riscada', '2022-07-02 20:54:54', '0000-00-00 00:00:00', 1, 'Não liga', 'Usado', '78€', 14, 'Concluido'),
(10, 7, 5, 'Apple', 'MacBook Air', '78jd012', 'Normal', '2022-07-02 21:11:35', '0000-00-00 00:00:00', 1, 'Tela rachada', 'Usado', '90', 1, 'Concluido'),
(11, 8, 6, 'Intel', 'IntelBook', '23423g', 'Perfeito Estado', '2022-07-02 21:25:46', '0000-00-00 00:00:00', 1, 'Fonte quebrada', 'Computador normal, Fonte Quebrada', '20', 1, 'Concluido'),
(12, 9, 7, 'teste1', 'teste1', 'teste1', 'teste1', '2022-07-02 21:47:07', '2022-07-02 21:54:49', 1, 'teste1', 'teste1', '999', 1, 'Concluido'),
(13, 10, 8, 'teste2', 'teste2', 'teste2', 'teste2', '2022-07-02 22:10:09', '2022-07-03 16:30:26', 1, 'teste2', 'teste2', '19', 1, 'Concluido'),
(14, 11, 9, 'teste3', 'teste3', 'teste3', 'teste3', '2022-07-03 16:32:24', '2022-07-03 16:33:35', 1, 'teste3', 'teste3', '4', 1, 'Concluido'),
(15, 12, 10, 'teste4', 'teste4', 'teste4', 'teste4', '2022-07-04 00:24:46', '2022-07-04 17:51:18', 1, 'teste4', 'teste4', '34', 1, 'Concluido'),
(16, 13, 12, 'teste5', 'teste5', 'teste5', 'teste5', '2022-07-04 10:05:13', '2022-07-18 11:44:52', 1, 'teste5', 'teste5', '666', 1, 'Concluido'),
(17, 14, 11, 'teste5', 'teste5', 'teste5', 'teste5', '2022-07-04 16:05:31', '2022-07-04 16:06:56', 1, 'teste5', 'teste5', '60', 1, 'Concluido'),
(18, 15, 17, 'teste6', 'teste6', 'teste6', 'teste6', '2022-07-04 17:18:12', '2022-07-18 11:44:54', 1, 'teste6', 'teste6', '34', 1, 'Concluido'),
(19, 16, 18, 'teste8', 'teste8', 'teste8', 'teste8', '2022-07-17 17:03:00', '2022-07-18 11:44:13', 1, 'teste8', 'teste8', '19', 1, 'Concluido'),
(20, 17, 19, 'teste9', 'teste9', 'teste9', 'teste9', '2022-07-17 17:08:02', '2022-07-17 17:10:36', 1, 'teste9', 'teste9', '999', 1, 'Concluido'),
(21, 18, 20, 'teste10', 'teste10', 'teste10', 'teste10', '2022-07-17 17:13:59', '2022-07-18 11:44:15', 1, 'teste10', 'teste10', '999', 1, 'Concluido'),
(22, 19, 21, 'teste11', 'teste11', 'teste11', 'teste11', '2022-07-17 17:18:05', '2022-07-18 11:44:18', 1, 'teste11', 'teste11', '999', 1, 'Concluido'),
(23, 20, 22, 'teste12', 'teste12', 'teste12', 'teste12', '2022-07-17 17:22:28', '2022-07-18 11:44:47', 1, 'teste12', 'teste12', '666', 1, 'Concluido'),
(24, 23, 25, 'teste13', 'teste13', 'teste13', 'teste13', '2022-07-17 17:32:21', '2022-07-18 11:44:09', 1, 'teste13', 'teste13', '77', 1, 'Concluido'),
(25, 21, 23, 'Intel', 'Notebook', 'm5q4f39', 'testeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', '2022-07-18 08:32:51', '2022-07-18 08:32:51', 1, 'Tela não liga, fonte não carrega', 'usado', '897', NULL, 'Retirar'),
(26, 22, 24, 'teste50', 'teste50', 'teste50', 'teste50', '2022-07-18 11:28:15', '2022-07-18 11:44:58', 1, 'teste50', 'teste50', '44', 1, 'Concluido'),
(27, NULL, NULL, 'HP', 'Viper HD4', '9KG79S', 'Coberto de poeira, tela riscada e teclado sem as teclas Q,W,G,H', '2022-07-18 11:50:19', '2022-07-18 11:50:19', 1, 'computador não liga', 'Muito desgastado', NULL, NULL, 'Em espera');

-- --------------------------------------------------------

--
-- Estrutura da tabela `relations`
--

CREATE TABLE `relations` (
  `id_eqp` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `id_wkr` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `relations`
--

INSERT INTO `relations` (`id_eqp`, `id_client`, `id_wkr`) VALUES
(27, 17, NULL),
(6, 7, 1),
(7, 13, 1),
(8, 13, 1),
(10, 13, 1),
(11, 14, 1),
(12, 14, 1),
(13, 13, 1),
(14, 13, 1),
(15, 13, 1),
(16, 13, 1),
(17, 13, 1),
(18, 13, 1),
(19, 13, 1),
(20, 16, 1),
(21, 16, 1),
(22, 16, 1),
(23, 16, 1),
(24, 13, 1),
(25, 13, 1),
(26, 13, 1),
(9, 7, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `repair`
--

CREATE TABLE `repair` (
  `id_rp` int(11) NOT NULL,
  `id_wkr` int(11) NOT NULL,
  `id_eqp` int(11) NOT NULL,
  `date_repair_rp` timestamp NOT NULL DEFAULT current_timestamp(),
  `observations_rp` longtext NOT NULL,
  `duration_rp` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `repair`
--

INSERT INTO `repair` (`id_rp`, `id_wkr`, `id_eqp`, `date_repair_rp`, `observations_rp`, `duration_rp`) VALUES
(1, 1, 6, '2022-07-02 18:44:28', 'Moderado', '6'),
(2, 14, 9, '2022-07-02 21:02:21', 'Tudo ocorrido nos conformes', '34'),
(3, 1, 8, '2022-07-02 21:05:59', 'gggggggggg', '4'),
(4, 1, 7, '2022-07-02 21:10:42', 'normal', '4'),
(5, 1, 10, '2022-07-02 21:13:39', 'Tudo ocorrido Normalmente', '19'),
(6, 1, 11, '2022-07-02 21:27:55', 'Tudo ocorrido normalmente', '666'),
(7, 1, 12, '2022-07-02 21:48:35', 'teste', '19'),
(8, 1, 13, '2022-07-03 16:28:53', 'teste', '19'),
(9, 1, 14, '2022-07-03 16:33:23', 'teste3', '4'),
(10, 1, 15, '2022-07-04 00:30:06', 'teste4', '34'),
(11, 1, 17, '2022-07-04 16:06:20', 'teste', '19'),
(12, 1, 16, '2022-07-04 19:10:09', 'tedte', '999'),
(13, 1, 18, '2022-07-17 16:28:08', 'normal', '6'),
(14, 1, 18, '2022-07-17 16:29:50', 'normal', '6'),
(15, 1, 18, '2022-07-17 16:34:33', 'normal', '6'),
(16, 1, 18, '2022-07-17 16:57:17', 'normal', '6'),
(17, 1, 18, '2022-07-17 16:58:10', 'normal', '6'),
(18, 1, 19, '2022-07-17 17:03:52', 'teste8', '6'),
(19, 1, 20, '2022-07-17 17:09:31', 'teste9', '666'),
(20, 1, 21, '2022-07-17 17:14:41', 'teste10', '34'),
(21, 1, 22, '2022-07-17 17:18:42', 'teste11', '999'),
(22, 1, 23, '2022-07-17 17:22:54', 'teste12', '666'),
(23, 1, 25, '2022-07-18 11:37:31', 'testeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', '44'),
(24, 1, 26, '2022-07-18 11:41:44', 'teste50', '44'),
(25, 1, 24, '2022-07-18 11:43:54', 'jhgf', '44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `roles`
--

CREATE TABLE `roles` (
  `id_role` int(11) NOT NULL,
  `name_role` varchar(250) NOT NULL,
  `char_role` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `roles`
--

INSERT INTO `roles` (`id_role`, `name_role`, `char_role`) VALUES
(1, 'Rececionista', 'r'),
(2, 'Engenheiro', 't'),
(3, 'Administrador', 'a');

-- --------------------------------------------------------

--
-- Estrutura da tabela `workers`
--

CREATE TABLE `workers` (
  `id_wkr` int(11) NOT NULL,
  `name_wkr` varchar(250) NOT NULL,
  `role_wkr` varchar(50) NOT NULL,
  `email_wkr` varchar(250) NOT NULL,
  `pass_wkr` varchar(250) NOT NULL,
  `phone_wkr` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `workers`
--

INSERT INTO `workers` (`id_wkr`, `name_wkr`, `role_wkr`, `email_wkr`, `pass_wkr`, `phone_wkr`) VALUES
(1, 'teste', 'rta', 'joaodacax@gmail.com', '71d6c631e36a3432a5899bb09c51d52a', '000123'),
(2, 'tess', '[\"r\",\"t\",\"a\"]', 'teste@gmail.com', '71d6c631e36a3432a5899bb09c51d52a', '0000'),
(13, 'funcionario', '[\"t\",\"a\"]', 'funcionario@gmai.com', '71d6c631e36a3432a5899bb09c51d52a', '00000'),
(14, 'Jorge', '[\"t\"]', 'jorge@gmail.com', '71d6c631e36a3432a5899bb09c51d52a', '010101');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_client`);

--
-- Índices para tabela `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD PRIMARY KEY (`id_dg`),
  ADD KEY `worker` (`id_wkr`),
  ADD KEY `equipamento` (`id_eqp`);

--
-- Índices para tabela `equipament`
--
ALTER TABLE `equipament`
  ADD PRIMARY KEY (`id_eqp`),
  ADD KEY `reception` (`reception_wrk_eqp`),
  ADD KEY `handed` (`handed_wkr_eqp`),
  ADD KEY `diagnose` (`id_dg`),
  ADD KEY `repair` (`id_rp`);

--
-- Índices para tabela `relations`
--
ALTER TABLE `relations`
  ADD PRIMARY KEY (`id_eqp`,`id_client`),
  ADD KEY `tab_wkr` (`id_wkr`),
  ADD KEY `tab_client` (`id_client`);

--
-- Índices para tabela `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`id_rp`),
  ADD KEY `repair_worker` (`id_wkr`),
  ADD KEY `repair_equipament` (`id_eqp`);

--
-- Índices para tabela `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_role`);

--
-- Índices para tabela `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id_wkr`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clients`
--
ALTER TABLE `clients`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `diagnosis`
--
ALTER TABLE `diagnosis`
  MODIFY `id_dg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `equipament`
--
ALTER TABLE `equipament`
  MODIFY `id_eqp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `repair`
--
ALTER TABLE `repair`
  MODIFY `id_rp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `roles`
--
ALTER TABLE `roles`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `workers`
--
ALTER TABLE `workers`
  MODIFY `id_wkr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD CONSTRAINT `equipamento` FOREIGN KEY (`id_eqp`) REFERENCES `equipament` (`id_eqp`),
  ADD CONSTRAINT `worker` FOREIGN KEY (`id_wkr`) REFERENCES `workers` (`id_wkr`);

--
-- Limitadores para a tabela `equipament`
--
ALTER TABLE `equipament`
  ADD CONSTRAINT `diagnose` FOREIGN KEY (`id_dg`) REFERENCES `diagnosis` (`id_dg`),
  ADD CONSTRAINT `handed` FOREIGN KEY (`handed_wkr_eqp`) REFERENCES `workers` (`id_wkr`),
  ADD CONSTRAINT `reception` FOREIGN KEY (`reception_wrk_eqp`) REFERENCES `workers` (`id_wkr`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `relations`
--
ALTER TABLE `relations`
  ADD CONSTRAINT `tab_client` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`),
  ADD CONSTRAINT `tab_eqp` FOREIGN KEY (`id_eqp`) REFERENCES `equipament` (`id_eqp`),
  ADD CONSTRAINT `tab_wkr` FOREIGN KEY (`id_wkr`) REFERENCES `workers` (`id_wkr`);

--
-- Limitadores para a tabela `repair`
--
ALTER TABLE `repair`
  ADD CONSTRAINT `repair_equipament` FOREIGN KEY (`id_eqp`) REFERENCES `equipament` (`id_eqp`),
  ADD CONSTRAINT `repair_worker` FOREIGN KEY (`id_wkr`) REFERENCES `workers` (`id_wkr`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
