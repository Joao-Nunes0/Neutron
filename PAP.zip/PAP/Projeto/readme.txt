A conta para o backoffice com todas as permissões é email: joaodacax@gmail.com ; senha: porto 

A senha para todas as contas é porto

Caso algo de problema o fique desformatado pode ser por conta de serem diferentes versões de PHP