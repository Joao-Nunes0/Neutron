<?php
$nif = $_GET['nif'];
$px=1;
if(isset($_GET['px']))
$px = $_GET['px'];

$itens=5;
$li = ($px-1)*5;
$ls = 5;

$sql2 = "SELECT count(*) as nEquipamento FROM equipament,relations,clients WHERE nif_client = $nif AND relations.id_eqp = equipament.id_eqp AND relations.id_client = clients.id_client ORDER BY equipament.date_reception_eqp DESC ";

$resultado = mysqli_query($conn,$sql2);
if (!$resultado) {
  echo ' Falha na consulta: '. mysqli_error($conn);
}
else{
  $row = mysqli_fetch_assoc($resultado);
  $nEquipamento = $row['nEquipamento'];

  $num_paginas = ceil($nEquipamento/$itens);

  $sql="SELECT * FROM equipament,relations,clients WHERE nif_client = $nif AND relations.id_eqp = equipament.id_eqp AND relations.id_client = clients.id_client ORDER BY equipament.date_reception_eqp DESC LIMIT $li,$ls";

  ?>
  <br>


  <?php
  $resultado = mysqli_query($conn,$sql);
  if (!$resultado || mysqli_num_rows($resultado) == 0){ ?>
    <center>
      <div class="opsimg">
        <img src="https://cdn.dribbble.com/users/1499090/screenshots/8050538/media/12aa43bdaab5ab719ffb8fefed40a7b3.jpg?compress=1&resize=400x300" style="width: 600px; height:338px; border-radius: 10px;">
      </div>
    </center>

  <?php }else{
    ?>
    <center>
    <div id="alerts" style="width: 70%;z-index: 2; position: absolute; top:20%; left:15%;">

    </div>
<div class="container" id="container table">
      <div class="container bg-secondary" id="title-h3" style="color:white;">
        <br>
        <h2>Histórico de equipamentos</h2>
        <br>
      </div>
      <div class="table-responsive" id="table-encomenda">
        <table class="table table-striped table-hover" id="myTable">
          <thead>
            <tr>
              <th scope="col" class="text-center">Id do equipamento</th>
              <th scope="col" class="text-center">Marca</th>
              <th scope="col" class="text-center">Modelo</th>
              <th scope="col" class="text-center">Nº Serie</th>
              <th scope="col" class="text-center">Data de recepção</th>
              <th scope="col" class="text-center">Status atual</th>
            </tr>
          </thead>
          <tbody>
            <?php
            while ($row = mysqli_fetch_array($resultado)){
              ?>
              <tr>
                <td class="text-center"><?php echo $row['id_eqp'];?></td>
                <td class="text-center"><?php echo $row['brand_eqp'];?></td>
                <td class="text-center"><?php echo $row['model_eqp'];?></td>
                <td class="text-center"><?php echo $row['seriesnum_eqp'];?></td>
                <td class="text-center"><?php echo $row['date_reception_eqp'];?></td>
                <td class="text-center"><?php echo $row['status_eqp'];?></td>
              </tr>
              <?php

            }
          }
          ?>
        </tbody>
      </table>
    </div>
</div>
    <!--///////////// PAGINAÇÃO ////////////////-->
    <div class="row justify-content-center" style="width:80%;">

      <div class="col- mb-3">

        <?php
        if($num_paginas >1) {
          ?>

          <nav>
            <ul class="pagination pagination-sm">
              <?php
              if($px>1) {
                ?>
                <li class="page-item">
                  <a class="page-link" href="./?p=2&px=<?php echo $px-1;?>" aria-label="Anterior">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only">Anterior</span>
                  </a>
                </li>
                <?php
              }
              for ($i=1; $i <= $num_paginas; $i++) {
                ?>
                <li class="page-item"><a class="page-link" href="./?p=2&px=<?php echo $i;?>"><?php echo $i;?></a></li>
                <?php
              }

              if($px<$num_paginas) {
                ?>
                <li class="page-item">
                  <a class="page-link" href="./?p=2&px=<?php echo $px+1;?>" aria-label="Próximo">
                    <span aria-hidden="true">&raquo;</span>
                    <span class="sr-only">Próximo</span>
                  </a>
                </li>
                <?php
              }
              ?>
            </ul>
          </nav>

          <?php
        }
        ?>
      </div>
    </div>

  </center>
<?php } ?>
