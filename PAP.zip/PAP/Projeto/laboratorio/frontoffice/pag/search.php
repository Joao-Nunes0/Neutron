<style>
body {
  background-image: url("https://www.leidainformatica.com/wp-content/uploads/2020/05/205-1024x576.jpg");
  background-color: #000000;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
}

.center {
  position: relative;
  top: 10%;
  left: 53%;
}
</style>
<body>
  <div class="form-row">
        <div class="form-group col-md-6 mb-1">
          <div class="center input-group mb-3">
            <button type="button" class="btn btn-outline-secondary bg-dark" id="search" style="color:white;"><i class="bi bi-search"></i></button>
            <input type="text" class="form-control" id="nif" aria-describedby="basic-addon1" placeholder="Introduza seu NIF para encontrar seus equipamentos">
            <img src="assets/img/icons/remove.png" alt="imagem não encontrada">
          </div>
        </div>
  </div>
</body>
<script>

$("#search").click(function(e){

  $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" aria-hidden="true" style="height: 40px; text-align: center; padding:7px;"><strong>Registro efetuado com sucesso</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
     window.scrollTo({ top: 0, behavior: 'smooth' });

  e.preventDefault();

  $.ajax({
    url: "../API/",
    method: "GET",
    data: {
        nif: $("#nif").val()
    }
  }).done(function (value) {
    var e = $("<div>");
    e.html(value);
    var nif = $("#nif").val();
    if (nif == "") {
      nif = 01;
    }
    var response = jQuery.parseJSON(e.html());
    location.href = "?p=2&nif=" + nif;

    if (response.success == false) {
      //console.log(e.html());
      $('#alerts').html('<div class="alert alert-danger alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
});

</script>
