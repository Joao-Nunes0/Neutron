<!-- Estilo do RODAPÉ -->
<style media="screen">

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 16px;
  text-decoration: none;
}

li:hover a{
  color: #00ff99;
}

.effect a {
    text-decoration: none !important;
    width: 35px;
    height: 35px;
    margin: 15px;
    display:inline-flex;
    align-items: center;
    justify-content: center;
    margin-right: 0px;
    overflow: hidden;
    position: relative;
    color: white; /*or change to your own color*/
    border: 1px solid; /*or change to your own color*/
    border-color: white;
  }

.effect a {
    transition: border-radius 0.2s linear 0s;
    transform: rotate(45deg);
  }

.effect i {
      transition: transform 0.01s linear 0s;
      transform: rotate(-45deg);
    }

.fb:hover i{
  color: #00ff99;
}

.fb:hover {
  border-color: #00ff99;
}

.insta:hover i{
  color: #00ff99;
}

.insta:hover {
  border-color: #00ff99;
}

</style>

<!-- RODAPÉ -->

<footer class="text-light bottom" style="background:#222222;">
  <div class="text-center" style="background-color: #222222; padding-bottom: 10px; margin-top:-10px;" >
    <div class="effect">
        <a href="https://www.facebook.com/profile.php?id=100083100960556" target="_blank" class="fb icone" title="Join us on Facebook"><i class="bx bxl-facebook bx-sm" aria-hidden="true"></i></a>
        <a href="https://www.instagram.com/neutron_ltda/" target="_blank" class="insta icone" title="Join us on Instagram"><i class="bx bxl-instagram bx-sm" aria-hidden="true"></i></a>
    </div>
    <p>    © 2021 - <?php echo date("Y") ?> Neutron Unipessoal LDA</p>
  </div>
</footer>
