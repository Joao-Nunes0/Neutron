  <?php
  $pag=0;
  if(isset($_GET['p']))
  $pag=$_GET['p'];

  require 'bd/bdconnect.php';
  ?>

  <html lang="pt">
  <head><meta charset="euc-jp">

    <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    .wrapper {
      min-height: 100%;
      margin-bottom: -50px;
    }
    .footer,
    .push {
      height: 50px;
    }
    </style>

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" type="image/png" href="assets/img/icons/remove.png"/>
    <title>Neutron</title>


    <!-- CSS LOCAL -->
    <link href="assets/css/styles.css" rel="stylesheet" />

    <!-- ICONS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.1/font/bootstrap-icons.css">

    <!-- DATATABLES PLUGIN -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.js"></script>

    <!-- CHARTS JS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>



  </head>
  <body class="sb-nav-fixed">
    <div class="wrapper">
      <div class="container-fluid px-4">

        <?php
        switch ($pag) {
          case '1':
          require 'pag/search.php'; break;
          case '2':
          require 'pag/table_eqp.php'; break;
          case '3':
          require 'pag/description.php'; break;
          default:
          require 'pag/search.php'; break;
        }
        ?>
      </div>

    <div class="push"></div>
    </div>
    <?php include 'includes/footer.php' ?>
  </body>
</html>
