<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="icon" type="image/png" href="../../assets/img/icons/remove.png"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>Login - Neutron</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

      <!-- BOOTSTRAP -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.1/font/bootstrap-icons.css">

</head>
<body class="bg-white">
  <div id="layoutAuthentication">
    <div id="layoutAuthentication_content">
      <main>
        <div class="container">
          <div class="container-login100">
            <!--Alerta se o login está errado-->
            <div id="alerts" style="width:80%; z-index: 2; position: absolute; top:80%; padding: 10px;">

            </div>
            <div class="row justify-content-center">
              <div class="col-lg-5">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                  <div class="card-header bg-dark"><center><img src="../../assets/img/icons/remove.png" alt="imagem não encontrada" style="height:80px;width:80px;"></center></div>
                  <div class="card-body">
                    <form id="backlogin">
                      <div class="form-floating mb-3">
                        <label for="inputEmail">Email address</label>
                        <input class="form-control" id="email" type="email" placeholder="name@example.com" />
                      </div>
                      <div class="form-floating mb-3">
                        <label for="inputPassword">Password</label>
                        <input class="form-control" id="senha" type="password" placeholder="Password" />
                      </div>
                      <center>
                      <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                        <button type="submit" class="btn btn-success" name="button">Login</button>
                      </div>
                    </center>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

<script src="../../js/scripts.js"></script>
<script type="text/javascript">

    $("#backlogin").submit(function(e){
      e.preventDefault();
      $.ajax({
        url: "../../../API/",
        method: "GET",
        data: {
          action: "authentication",
          execute: "login",
          email: $("#email").val(),
          password: $("#senha").val()
        }
      }).done(function (value) {
        var e = $("<div>");
        e.html(value);
        console.log(e.html());

        var response = jQuery.parseJSON(e.html());

        if (response.success == false) {
          //console.log(e.html());
          $('#alerts').html('<div class="alert alert-danger alert-dismissible fade show" role="alert" style="height: 60px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');

        } else {
          window.location.href = "../../";
        }
      });
    });
    </script>

  </body>
  </html>
