<script src="js/repair.js" crossorigin="anonymous"></script>

<h1 class="mt-4">Consertar equipamentos</h1>
<ol class="breadcrumb mb-4">
  <li class="breadcrumb-item"><a href="index.php">Geral</a></li>
  <li class="breadcrumb-item"><a href="?p=14">Diagnosticar equipamentos</a></li>
  <li class="breadcrumb-item active">Consertar equipamentos</li>
</ol>
<div class="card mb-4">
  <div class="card-header">
    <i class="fas fa-table me-1"></i>
    Consertar equipamentos
  </div>
  <div class="card-body table-responsive">
    <table id="tableRepair">
      <thead>
        <tr>
          <th>Marca</th>
          <th>Modelo</th>
          <th>Nº de Serie</th>
          <th>Data Recepção</th>
          <th>Ficha</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
      </table>
    </div>
  </div>
