<script src="js/worker.js" crossorigin="anonymous"></script>

<h1 class="mt-4">Funcionarios</h1>
<ol class="breadcrumb mb-4">
  <li class="breadcrumb-item"><a href="index.php">Geral</a></li>
  <li class="breadcrumb-item active">Funcionarios</li>
</ol>
<div class="card mb-4">
  <div class="card-header">
    <i class="fas fa-table me-1"></i>
    Funcionarios atuais
    <div class="col-md-12 bg-light text-right">
      <a href="?p=5">
      <button type="submit" class="btn btn-success">Criar Funcionarios</button>
      </a>
    </div>
  </div>
  <div class="card-body table-responsive">
    <table id="tableWorker" >
      <thead>
        <tr>
          <th>Id</th>
          <th>Nome</th>
          <th>Email</th>
          <th>Telemovel</th>
          <th>Editar</th>
          <th>Apagar</th>
          <th>Reset senha</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
      </table>
    </div>
  </div>
