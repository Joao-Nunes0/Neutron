<script src="js/clients.js" crossorigin="anonymous"></script>

<h1 class="mt-4">Clientes</h1>
<ol class="breadcrumb mb-4">
  <li class="breadcrumb-item"><a href="index.php">Geral</a></li>
  <li class="breadcrumb-item active">Clientes</li>
</ol>
<div class="card mb-4">
  <div class="card-header">
    <i class="fas fa-table me-1"></i>
    Clientes
  </div>
  <div class="card-body table-responsive">
    <table id="tableClients" >
      <thead>
        <tr>
          <th>Id</th>
          <th>Nome</th>
          <th>NIF</th>
          <th>Email</th>
          <th>Telemovel</th>
          <th>Morada</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
      </table>
    </div>
  </div>
