<script src="js/equipamentosC.js" crossorigin="anonymous"></script>

<h1 class="mt-4">Equipamentos Completos</h1>
<ol class="breadcrumb mb-4">
  <li class="breadcrumb-item"><a href="index.php">Geral</a></li>
  <li class="breadcrumb-item"><a href="?p=3">Pendentes</a></li>
  <li class="breadcrumb-item active">Completas</li>
</ol>
<div class="card mb-4">
  <div class="card-header">
    <i class="fas fa-table me-1"></i>
    Equipamentos Completos
  </div>
  <div class="card-body table-responsive">
    <table id="tableEquipC">
      <thead>
        <tr>
          <th>Nome cliente</th>
          <th>Marca</th>
          <th>Modelo</th>
          <th>Nº Serie</th>
          <th>Ficha</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
      </table>
    </div>
  </div>
