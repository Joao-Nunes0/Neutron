<br>
<div id="alerts">
</div>
<div class="container bg-dark">
  <br>
  <center>
    <h2 for="basic-url" style="color:white;">Inserir Funcionario</h2>
  </center>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Nome</span>
          </div>
          <input type="text" class="form-control" id="name" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Email</span>
          </div>
          <input type="text" class="form-control" id="email" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Senha</span>
          </div>
          <input type="text" class="form-control" id="pass" aria-describedby="basic-addon1">
        </div>
      </div>
</div>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Telemovel</span>
          </div>
          <input type="text" class="form-control" id="phone" aria-describedby="basic-addon1">
        </div>
      </div>

      <fieldset id="tipo">
        <?php
        $sql = "SELECT * FROM roles";
        $result = mysqli_query($conn,$sql);
        if(!$result)
            echo "Erro ao aceder à tabela: " .mysql_error();
        else if (mysqli_num_rows($result)>0){
                $cont=0;
              while ($row = mysqli_fetch_array($result)){
          ?>
        <div class="form-check form-check-inline">
            <input class="form-check-input" id="role" type="checkbox" name="tipo" value="<?php echo $row['char_role'] ?>">
            <label class="form-check-label" for="tipo" style="color:white;"><?php echo $row['name_role'] ?></label>
        </div>
        <?php
              }
            }
         ?>
    </fieldset>
</div>
<center>
  <button id="inserirW" class="btn btn-outline-success">Enviar</button>
</center>
<br>
</div>
<script type="text/javascript">

$("#inserirW").click(function(e){

    var i = 0;
    var save = [];
    $('.form-check-input:checked').each(function () {
        save[i++] = $(this).val();
    });

  $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" aria-hidden="true" style="height: 40px; text-align: center; padding:7px;"><strong>Registro efetuado com sucesso</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
     window.scrollTo({ top: 0, behavior: 'smooth' });

  e.preventDefault();

  $.ajax({
    url: "../API/",
    method: "GET",
    data: {
        action: "order",
        execute: "insertW",
        name: $('#name').val(),
        email: $("#email").val(),
        phone: $("#phone").val(),
        role: JSON.stringify(save),
        pass: $("#pass").val()
    }
  }).done(function (value) {
    var e = $("<div>");
    e.html(value);

    console.log(e.html());
    var response = jQuery.parseJSON(e.html());

    if (response.success == false) {
      $('#alerts').html('<div class="alert alert-danger alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      window.location.href = "?p=6";
    }
  });
});

</script>
