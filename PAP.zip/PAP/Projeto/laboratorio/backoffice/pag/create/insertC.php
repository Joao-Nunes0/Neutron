<br>
<div id="alerts">
</div>
<div class="container bg-dark">
  <br>
  <center>
    <h2 for="basic-url" style="color:white;">Cliente</h2>
  </center>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Nome</span>
          </div>
          <input type="text" class="form-control" id="name" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Email</span>
          </div>
          <input type="text" class="form-control" id="email" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">NIF</span>
          </div>
          <input type="text" class="form-control" id="nif" aria-describedby="basic-addon1">
        </div>
      </div>
</div>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Telemovel</span>
          </div>
          <input type="text" class="form-control" id="phone" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-8 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Morada</span>
          </div>
          <input type="text" class="form-control" id="address" aria-describedby="basic-addon1">
        </div>
      </div>
</div>
<center>
  <button id="inserirC" class="btn btn-outline-success">Enviar</button>
</center>
<br>
</div>
<script type="text/javascript">

$("#inserirC").click(function(e){

  $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" aria-hidden="true" style="height: 40px; text-align: center; padding:7px;"><strong>Registro efetuado com sucesso</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
     window.scrollTo({ top: 0, behavior: 'smooth' });

  e.preventDefault();

  $.ajax({
    url: "../API/",
    method: "GET",
    data: {
        action: "order",
        execute: "insertC",
        name: $('#name').val(),
        email: $("#email").val(),
        phone: $("#phone").val(),
        nif: $("#nif").val(),
        address: $("#address").val()
    }
  }).done(function (value) {
    var e = $("<div>");
    e.html(value);

    var response = jQuery.parseJSON(e.html());

    if (response.success == false) {
      //console.log(e.html());
      $('#alerts').html('<div class="alert alert-danger alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      window.location.href = "?p=11";
    }
  });
});

</script>
