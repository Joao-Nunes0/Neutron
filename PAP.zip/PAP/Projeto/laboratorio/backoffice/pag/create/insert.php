<body>
<br>
<div id="alerts">
</div>
<div class="container bg-dark">
  <br>
  <center>
    <h2 for="basic-url" class="form-label" style="color:white;">Cliente</h2>
  </center>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">NIF</span>
          </div>
          <input type="text" class="form-control" id="nif" aria-describedby="basic-addon1">
        </div>
      </div>
</div>
<center>
  <h2 for="basic-url" class="form-label" style="color:white;">Produto</h2>
</center>
<div class="form-row">
      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Marca</span>
          </div>
          <input type="text" class="form-control" id="brand" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Modelo</span>
          </div>
          <input type="text" class="form-control" id="model" aria-describedby="basic-addon1">
        </div>
      </div>

      <div class="form-group col-md-4 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Nº de serie</span>
          </div>
          <input type="text" class="form-control" id="seriesnum" aria-describedby="basic-addon1">
        </div>
      </div>
</div>
<div class="form-row">
      <div class="form-group col-md-12 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Observações</span>
          </div>
          <textarea class="form-control" aria-label="With textarea" id="observ"></textarea>
        </div>
      </div>
</div>
<div class="form-row">
      <div class="form-group col-md-12 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Sintomas</span>
          </div>
          <textarea class="form-control" aria-label="With textarea" id="simp"></textarea>
        </div>
      </div>
</div>
<div class="form-row">
      <div class="form-group col-md-12 mb-1">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Estado</span>
          </div>
          <textarea class="form-control" aria-label="With textarea" id="state"></textarea>
        </div>
      </div>
</div>
<center>
  <button id="inserir" class="btn btn-outline-success">Enviar</button>
</center>
<br>
</div>
</body>
<script type="text/javascript">

$("#inserir").click(function(e){

  $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" aria-hidden="true" style="height: 40px; text-align: center; padding:7px;"><strong>Registro efetuado com sucesso</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
     window.scrollTo({ top: 0, behavior: 'smooth' });

  e.preventDefault();

  $.ajax({
    url: "../API/",
    method: "GET",
    data: {
        action: "order",
        execute: "insert",
        nif: $("#nif").val(),
        brand: $('#brand').val(),
        model: $("#model").val(),
        series: $("#seriesnum").val(),
        observ: $("#observ").val(),
        simp: $("#simp").val(),
        state: $("#state").val()
    }
  }).done(function (value) {
    var e = $("<div>");
    e.html(value);
    console.log(e.html());
    var response = jQuery.parseJSON(e.html());

    if (response.success == false) {
      //console.log(e.html());
      $('#alerts').html('<div class="alert alert-danger alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      $('#alerts').html('<div class="alert alert-success alert-dismissible fade show" role="alert" style="height: 40px; text-align: center; padding:7px;"><strong>' + response.description + '</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close" style="padding: 8px 10px 0 0px;"><span aria-hidden="true">&times;</span></button></div>');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      window.location.href = "?p=3";
    }
  });
});

</script>
