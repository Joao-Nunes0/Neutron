<?php
/* UMA CLASSE COM O OBJETIVO DE ESTABLECER UM PADRÃO DE COMUNICAÇÃO COM O CLIENTE! */

class Order {
  public $id;
  public $name;
  public $email;
  public $roles;
  public $phone;


  public function __construct($id, $name, $email, $roles, $phone)
  {
    $this->id = $id;
    $this->name = $name;
    $this->email = $email;
    $this->roles = $roles;
    $this->phone = $phone;
  }

}
?>
