<?php
/* UMA CLASSE COM O OBJETIVO DE ESTABLECER UM PADRÃO DE COMUNICAÇÃO COM O CLIENTE! */

class Order {
  public $id_eqp;
  public $id_client;
  public $brand;
  public $model;
  public $series;
  public $date;
  public $simp;
  public $state;


  public function __construct($id_eqp, $id_client, $brand, $model, $series, $date, $simp, $state)
  {
    $this->id_eqp = $id_eqp;
    $this->id_client = $id_client;
    $this->brand = $brand;
    $this->model = $model;
    $this->series = $series;
    $this->date = $date;
    $this->simp = $simp;
    $this->state = $state;
  }

}
?>
