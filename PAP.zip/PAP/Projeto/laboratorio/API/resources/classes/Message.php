<?php
/* UMA CLASSE COM O OBJETIVO DE ESTABLECER UM PADRÃO DE COMUNICAÇÃO COM O CLIENTE! */
class Message {
  public $success; //$success É UM BOOLEANO
  public $description; //$description É UMA STRING
  public $data; //$data É UM ARRAY

  public function __construct($success, $data)
  {
    $this->success = $success;
    $this->data = $data;
    $this->description = $success ? "Executado com sucesso." : "Ocorreu um erro." ; //RESPOSTA PADRÃO PARA O CLIENTE NO CAMPO DESCRIÇÃO
  }


  function setDescription($description){ //DESCRIPTION SETTER
    $this->description = $description;
    return $this;
  }

  function setData($data){ //DATA SETTER
    $this->data = $data;
    return $this;
  }

  public function encode(){ //CONSTROI UM ARRAY DE RESPOSTA CUJO O QUAL VAI SER CONVERTIDO EM JSON
    $desc = $this->description;
    if ($this->data != null) {
      return json_encode(array(
        'success' => $this->success,
        'description' => $desc,
        'data' => $this->data
      ), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    }
    return json_encode(array(
      'success' => $this->success,
      'description' => $desc), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    }
  }
  ?>
