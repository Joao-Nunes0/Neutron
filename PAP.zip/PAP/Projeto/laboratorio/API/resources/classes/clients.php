<?php
/* UMA CLASSE COM O OBJETIVO DE ESTABLECER UM PADRÃO DE COMUNICAÇÃO COM O CLIENTE! */

class Order {
  public $id;
  public $name;
  public $nif;
  public $email;
  public $phone;
  public $address;


  public function __construct($id, $name, $nif, $email, $phone, $address)
  {
    $this->id = $id;
    $this->name = $name;
    $this->nif = $nif;
    $this->email = $email;
    $this->phone = $phone;
    $this->address = $address;
  }

}
?>
