<?php
/* UMA CLASSE COM O OBJETIVO DE ESTABLECER UM PADRÃO DE COMUNICAÇÃO COM O CLIENTE! */

class Order {
  public $id;
  public $name_client;
  public $brand;
  public $model;
  public $series;
  public $obs;
  public $date;
  public $simp;
  public $state;
  public $status;


  public function __construct($id, $name_client, $brand, $model, $series, $obs, $date, $simp, $state, $status)
  {
    $this->id = $id;
    $this->name_client = $name_client;
    $this->brand = $brand;
    $this->model = $model;
    $this->series = $series;
    $this->obs = $obs;
    $this->date = $date;
    $this->simp = $simp;
    $this->state = $state;
    $this->status = $status;
  }

}
?>
