<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'resources/PHPMailer/src/Exception.php';
require 'resources/PHPMailer/src/PHPMailer.php';
require 'resources/PHPMailer/src/SMTP.php';

function fileUploaded()
{
    if(empty($_FILES)) {
        return false;
    }
    return true;
}

try{
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (isset($_SESSION['control'])) {
      if ($_GET['execute'] == "insert") { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.
          if ((!filter_var($_GET['nif']) || !filter_var($_GET['brand']) || !filter_var($_GET['observ']) || !filter_var($_GET['simp']) || !filter_var($_GET['state'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O Cliente precisa de obrigatoriamente de um Nif, Marca, observação, sintomas e estado.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else{
            $nif = "SELECT * FROM clients WHERE nif_client = ".$_GET['nif'];
            $count = mysqli_num_rows(mysqli_query($conn,$nif));
            if ($count < 1) {
              echo (new Message(false, null))->setDescription("Não existe um cliente com este NIF.")->encode();
              }else{
                  $nif = $_GET['nif'];
                  $brand = $_GET['brand'];
                  $model = $_GET['model'];
                  $series = $_GET['series'];
                  $obs = $_GET['observ'];
                  $simp = $_GET['simp'];
                  $state = $_GET['state'];

                  $sql = "INSERT INTO equipament(brand_eqp,model_eqp,seriesnum_eqp,observations_eqp,reception_wrk_eqp,simptons_eqp,state_eqp,status_eqp) values('".$brand."','".$model."','".$series."','".$obs."','". $_SESSION["worker"]["id"] ."','".$simp."','".$state."','Em espera')";
                  $result = mysqli_query($conn,$sql);
                  if(!$result)
                  echo "Erro ao aceder à tabela: " .mysql_error();

                  $sql2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM clients WHERE nif_client = $nif"));
                  $sql3 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `equipament` ORDER BY `equipament`.`date_reception_eqp` DESC LIMIT 1"));
                  $sql4 = mysqli_query($conn,"INSERT into relations(id_eqp,id_client) values(".$sql3['id_eqp'].",".$sql2['id_client'].")");

                  $id = "SELECT name_client,email_client FROM clients WHERE nif_client = $nif";
                  $rst = mysqli_query($conn,$id);
                  $rt = mysqli_fetch_array($rst);
                  $email = $rt['email_client'];
                  $name = $rt['name_client'];
                  //Message
                  $mail = new PHPMailer(true);
                  try{
                  $mail->SMTPOptions = array(
                      'ssl' => array(
                      'verify_peer' => false,
                      'verify_peer_name' => false,
                      'allow_self_signed' => true
                      )
                  );
                  $mail->CharSet = 'UTF-8';
                  $mail->IsSMTP();  // enable SMTP
                  //$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
                  $mail->SMTPAuth = true; // authentication enabled
                  $mail->SMTPSecure = 'tls';// secure transfer enabled REQUIRED for Hostgator
                  $mail->Host = "smtp.mailtrap.io";
                  $mail->Port = 2525; // or 587
                  $mail->Username = "f8ed36f3578416";
                  $mail->Password = "2b37c43efad870";
                  $mail->SetFrom("NeutronLTDA@example.com","Neutron LTDA");
                  $mail->AddAddress("$email");

                  // Conteúdo da mensagem
                  $mail->isHTML(true);  // Seta o formato do e-mail para aceitar conteúdo HTML
                  $mail->Subject = 'Equipamento recebido com sucesso';
                  $mail->Body    = 'Olá '.$name.' seu equipamento foi inserido com sucesso em nosso inventario.<br> Caso queira consultar o estado de seu equipamento acesse o nosso <a href="http://localhost/laboratorio/frontoffice/">site</a>.<br> NeutronLTDA - <a href="https://www.instagram.com/neutron_ltda/"> Instagram</a> - <a href="https://www.facebook.com/profile.php?id=100083100960556"> Facebook </a>';
                  $mail->AltBody = 'Este é o corpo da mensagem para clientes de e-mail que não reconhecem HTML';
                  // Enviar

                  $mail->send();
                  echo (new Message(true, null))->setDescription("Email enviado para o cliente")->encode();
                  }catch (Exception $e){
                    echo (new Message(false, null))->setDescription("Message could not be sent. Mailer Error: {$mail->ErrorInfo}")->encode();
                  }
              }
            }
        }elseif ($_GET['execute'] == "insertC") {
          if ((!filter_var($_GET['nif']) || !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL) || !filter_var($_GET['name'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O Cliente precisa de obrigatoriamente de um Nome, Email e Nif.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            $nif = $_GET['nif'];
            $email = $_GET['email'];
            $address = $_GET['address'];
            $phone = $_GET['phone'];
            $name = $_GET['name'];

            $sql = "INSERT INTO clients(name_client,nif_client,phone_client,email_client,address_client) Values('$name',$nif,'$phone','$email','$address')";
            $result = mysqli_query($conn,$sql);
            if(!$result)
            echo "Erro ao aceder à tabela: " .mysql_error();
            $sql2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `clients` ORDER BY `clients`.`id_client` DESC LIMIT 1"));
              echo (new Message(true, array("id" => $sql2['id_client'])))->setDescription("Inserido com Sucesso")->encode();
          }
        }elseif ($_GET['execute'] == "insertW") {
          if ((!filter_var($_GET['name']) || !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL) || !filter_var($_GET['pass'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O trabalhador precisa de obrigatoriamente de um Email, Nome e Senha.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            $role = $_GET['role'];
            $email = $_GET['email'];
            $pass = md5($_GET['pass']);
            $phone = $_GET['phone'];
            $name = $_GET['name'];

            $sql = "INSERT INTO workers(name_wkr,role_wkr,email_wkr,pass_wkr,phone_wkr) Values('$name','$role','$email','$pass','$phone')";
            $result = mysqli_query($conn,$sql);
            if(!$result)
            echo "Erro ao aceder à tabela: " .mysql_error();
            $sql2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `clients` ORDER BY `clients`.`id_client` DESC LIMIT 1"));
              echo (new Message(true, array("id" => $sql2['id_client'])))->setDescription("Inserido com Sucesso")->encode();
          }
        }elseif ($_GET['execute'] == "insertDiagnose") {
          if ((!filter_var($_GET['diagnose'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O Diagnostico não foi inserido.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            $id_eqp = $_GET['id_eqp'];
            $id_client = $_GET['id_client'];
            $id_wkr = $_GET['id_wkr'];
            $diagnose = $_GET['diagnose'];
            $duration = $_GET['duration'];

            $sql = "INSERT INTO diagnosis(id_wkr,id_eqp,diagnosis_dg,duration_dg) Values($id_wkr,$id_eqp,'$diagnose','$duration')";
            $result = mysqli_query($conn,$sql);
            if(!$result)
            echo "Erro ao aceder à tabela: " .mysql_error();

            $sql2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `diagnosis` ORDER BY `diagnosis`.`id_dg` DESC LIMIT 1"));
            $sql3 = "UPDATE equipament SET id_dg = ".$sql2['id_dg']." WHERE id_eqp = $id_eqp";
            $resultado = mysqli_query($conn,$sql3);
            if(!$resultado)
            echo "Erro ao aceder à tabela: " .mysql_error();

            $sql4 = "UPDATE relations SET id_wkr = null WHERE id_eqp = $id_eqp AND id_client = $id_client";
            $resul = mysqli_query($conn,$sql4);
            if(!$resul)
            echo "Erro ao aceder à tabela: " .mysql_error();

            echo (new Message(true, array("id" => $id_eqp)))->setDescription("Diagnostico inserido com Sucesso")->encode();
          }
        }elseif ($_GET['execute'] == "insertRepair") {
          if ((!filter_var($_GET['obs']) || !filter_var($_GET['price'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("Observações sobre o reparo ou o preço não foram inseridos.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            $id_eqp = $_GET['id_eqp'];
            $id_wkr = $_GET['id_wkr'];
            $obs = $_GET['obs'];
            $price = $_GET['price'];
            $duration = $_GET['duration'];

            $sql = "INSERT INTO repair(id_wkr,id_eqp,observations_rp,duration_rp) Values($id_wkr,$id_eqp,'$obs','$duration')";
            $result = mysqli_query($conn,$sql);
            if(!$result)
            echo "Erro ao aceder à tabela: " .mysql_error();

            $sql2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `repair` ORDER BY `repair`.`id_rp` DESC LIMIT 1"));
            $sql3 = "UPDATE equipament SET id_rp = ".$sql2['id_rp'].", finalcost_eqp = '$price', status_eqp = 'Retirar' WHERE id_eqp = $id_eqp";
            $resultado = mysqli_query($conn,$sql3);
            if(!$resultado)
            echo "Erro ao aceder à tabela: " .mysql_error();

            $id = "SELECT email_client,name_client FROM relations,clients,equipament where equipament.id_eqp = $id_eqp AND equipament.id_eqp = relations.id_eqp AND clients.id_client = relations.id_client";
            $rst = mysqli_query($conn,$id);
            $rt = mysqli_fetch_array($rst);
            $email = $rt['email_client'];
            $name = $rt['name_client'];
            //Message
            $mail = new PHPMailer(true);
            try{
            $mail->SMTPOptions = array(
                'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
                )
            );
            $mail->CharSet = 'UTF-8';
            $mail->IsSMTP();  // enable SMTP
            //$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
            $mail->SMTPAuth = true; // authentication enabled
            $mail->SMTPSecure = 'tls';// secure transfer enabled REQUIRED for Hostgator
            $mail->Host = "smtp.mailtrap.io";
        	  $mail->Port = 2525; // or 587
            $mail->Username = "f8ed36f3578416";
    	      $mail->Password = "2b37c43efad870";
            $mail->SetFrom("NeutronLTDA@example.com","Neutron LTDA");
            $mail->AddAddress("$email");

            // Conteúdo da mensagem
            $mail->isHTML(true);  // Seta o formato do e-mail para aceitar conteúdo HTML
            $mail->Subject = 'Equipamento pronto para retirada';
            $mail->Body    = 'Olá '.$name.' seu equipamento está pronto para ser retirado em nossa loja.<br> O valor final do concerto foi '.$price.'.<br> NeutronLTDA - <a href="https://www.instagram.com/neutron_ltda/"> Instagram</a> - <a href="https://www.facebook.com/profile.php?id=100083100960556"> Facebook </a>';
            $mail->AltBody = 'Este é o corpo da mensagem para clientes de e-mail que não reconhecem HTML';
            // Enviar

            $mail->send();
            echo (new Message(true, null))->setDescription("Email enviado para o cliente")->encode();
            }catch (Exception $e){
              echo (new Message(false, null))->setDescription("Message could not be sent. Mailer Error: {$mail->ErrorInfo}")->encode();
            }
          }
        }elseif ($_GET['execute'] == "updateWorker") {
          if ((!filter_var($_GET['name']) || !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL)) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O trabalhador precisa de obrigatoriamente de um Email e Nome.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            $id = $_GET['id'];
            $role = $_GET['role'];
            $email = $_GET['email'];
            $phone = $_GET['phone'];
            $name = $_GET['name'];

            $sql = "UPDATE workers SET name_wkr = '$name', email_wkr = '$email', role_wkr = '$role', phone_wkr = '$phone' WHERE id_wkr = $id ";
            // executar o comando e testar se ocorreu erro
            if (!mysqli_query($conn,$sql)) {
              echo (new Message(false, null))->setDescription($sql)->encode();
              exit();
            }
            echo (new Message(true, null))->encode();
          }

        }elseif ($_GET['execute'] == "reseteWorker") {
            $id = $_GET['id'];

            $sql = "UPDATE workers SET pass_wkr = '71d6c631e36a3432a5899bb09c51d52a' WHERE id_wkr = $id ";
            // executar o comando e testar se ocorreu erro
            if (!mysqli_query($conn,$sql)) {
              echo (new Message(false, null))->setDescription($sql)->encode();
              exit();
            }
            echo (new Message(true, null))->encode();
        }elseif ($_GET['execute'] == "updateAccount") {
          if ((!filter_var($_GET['name']) || !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL) || !filter_var($_GET['pass'])) ){//Verifica se o email é vazio e valido assim também a password.
              echo (new Message(false, null))->setDescription("O funcionario precisa de obrigatoriamente de um Email, Nome e Senha.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
          }else {
            if ($_GET['pass'] == $_GET['pass2']) {
              $pass = $_GET['pass'];
            }else {
              $pass = md5($_GET['pass']);
            }
            $id = $_GET['id'];
            $email = $_GET['email'];
            $phone = $_GET['phone'];
            $name = $_GET['name'];

            $sql = "UPDATE workers SET name_wkr = '$name', email_wkr = '$email', pass_wkr = '$pass', phone_wkr = '$phone' WHERE id_wkr = $id ";
            // executar o comando e testar se ocorreu erro
            if (!mysqli_query($conn,$sql)) {
              echo (new Message(false, null))->setDescription($sql)->encode();
              exit();
            }
            echo (new Message(true, null))->encode();
          }

        }elseif ($_GET['execute'] == "updateWithdraw") {

          $id_eqp = $_GET['id_eqp'];
          $id_client = $_GET['id_client'];
          $id_wkr = $_GET['id_wkr'];

          $sql = "UPDATE equipament SET date_withdraw_eqp = null, handed_wkr_eqp = $id_wkr, status_eqp = 'Concluido' WHERE id_eqp = $id_eqp ";
          if (!mysqli_query($conn,$sql)) {
            echo (new Message(false, null))->setDescription($sql)->encode();
            exit();
          }
          echo (new Message(true, null))->encode();

        }elseif ($_GET['execute'] == "updateReference") {

          $id_eqp = $_GET['id_eqp'];
          $id_client = $_GET['id_client'];
          $id_wkr = $_GET['id_wkr'];

          $sql = "UPDATE relations SET id_wkr = $id_wkr WHERE id_eqp = $id_eqp AND id_client = $id_client";
          // executar o comando e testar se ocorreu erro
          if (!mysqli_query($conn,$sql)) {
            echo (new Message(false, null))->setDescription($sql)->encode();
            exit();
          }

          $sql2 = "UPDATE equipament SET status_eqp = 'Em reparo' WHERE id_eqp = $id_eqp";
          if (!mysqli_query($conn,$sql2)) {
            echo (new Message(false, null))->setDescription($sql2)->encode();
            exit();
          }
          echo (new Message(true, null))->encode();

        }elseif ($_GET['execute'] == "updateReferencied") {

          $id_eqp = $_GET['id_eqp'];
          $id_client = $_GET['id_client'];
          $id_wkr = $_GET['id_wkr'];

          $sql = "UPDATE relations SET id_wkr = null WHERE id_eqp = $id_eqp AND id_client = $id_client";
          // executar o comando e testar se ocorreu erro
          if (!mysqli_query($conn,$sql)) {
            echo (new Message(false, null))->setDescription($sql)->encode();
            exit();
          }

          $sql2 = "UPDATE equipament SET status_eqp = 'Em espera' WHERE id_eqp = $id_eqp";
          if (!mysqli_query($conn,$sql2)) {
            echo (new Message(false, null))->setDescription($sql2)->encode();
            exit();
          }
          echo (new Message(true, null))->encode();

        }elseif ($_GET['execute'] == "deleteWorker") {

          $id = $_GET['id'];

          $sql = "DELETE FROM workers WHERE id_wkr=".$id.";";
          $result = mysqli_query($conn,$sql);
          if (!$result){
            echo "Falha em apagar os dados: ".mysqli_error($conn);
            exit();
          }
          echo (new Message(true, null))->setDescription("Apagado com Sucesso")->encode();
        }else {
          echo (new Message(false, null))->setDescription("Não foi possivel executar a ação.")->encode();
        }
      }
}catch (Exception $e)
    {
        echo 'Exceção capturada: ',  $e->getMessage(), "\n";
    }
?>
