<?php //PERFORMAR TODAS AS AÇÕES RELACIONADAS A AUTENTICAÇÃO

require 'resources/PHPMailer/src/Exception.php';
require 'resources/PHPMailer/src/PHPMailer.php';
require 'resources/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

try{
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (isset($_SESSION['control'])) { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.


        /*////////////// SITEMA DE LOGIN/////////////// */
        if ($_GET['execute'] == "login") { //$_SESSION['execute'] serve para saber a ação que o cliente vai usar: inserir, remover, editar, login, logou e etc.

            if ((!isset($_GET['email']) || !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL)) || !isset($_GET['password']) ){//Verifica se o email é vazio e valido assim também a password.
                echo (new Message(false, null))->setDescription("Os campos email ou palavra-passe não foram específicados devidamente.")->encode();// Mensagem mostrada para o API e exposta para o cliente.
            }else {
                $senha = md5($_GET["password"]); //encriptação da senha
                $sql = mysqli_query($conn,"SELECT * FROM workers WHERE email_wkr = '$_GET[email]' AND pass_wkr = '$senha'");
                if (mysqli_num_rows($sql) > 0) {
                    $sql = mysqli_fetch_array($sql);
                $_SESSION['worker'] = array('id' => $sql['id_wkr'] , 'email' => $sql['email_wkr'], 'name' => $sql['name_wkr'], 'role' => $sql['role_wkr']); // colocando os dados da consulta para $_SESSION['user'].

                echo (new Message(true, null))->encode();
                }else {
                    echo (new Message(false, null))->setDescription("Credenciais incorretas, tente novamente.")->encode();//Se estiver com o email ou a senha errada no login.
                }
            }

        /*////////////// SITEMA DE LOGOUT/////////////// */
      }elseif ($_GET['execute'] == "logout") {

            unset($_SESSION['worker']);
            session_destroy();
            echo (new Message(true, null))->encode();


        /*////////////// SITEMA DE REGISTRO///////////////*/
        }elseif ($_GET['execute'] == "registo") {
            if ((!isset($_GET['email']) ||
                !filter_var($_GET['email'], FILTER_VALIDATE_EMAIL)) ||
                !isset($_GET['name']) ||
                !isset($_GET['role']) ||
                !isset($_GET['phone']) ||
                !isset($_GET['password'])){ //Verifica se os campos estão vazios.
                echo (new Message(false, null))->setDescription("Os campos não foram específicados devidamente.")->encode();

            }else {
                $password = md5($_GET["password"]);// encriptação da senha em md5
                $email = $_GET['email'];
                $name = $_GET['name'] ?? ' ';
                $role = $_GET['role'] ?? ' ';
                $phone = $_GET['phone'];


                $sql = mysqli_query($conn, "SELECT * FROM workers WHERE email_wrk='$email'");
                if (mysqli_num_rows($sql) > 0) {
                    echo (new Message(false, null))->setDescription("Esse email já está registado!")->encode();
                    exit();
                }

                //Inserir os dados na BD.
                $sql = "INSERT INTO workers (email_wkr, name_wkr, role_wkr, pass_wkr, phone_wkr) VALUES ('$email', '$name', '$role', '$password' , '$phone')";

                // executar o comando e testar se ocorreu erro
                if (!mysqli_query($conn,$sql)) {
                    echo (new Message(false, null))->setDescription("Falha ao executar a inserção:  \"$sql\" ". mysqli_error($conn))->encode();
                    exit();
                }
              }
        }else{
            echo (new Message(false, null))->setDescription("Não foi possivel executar a ação.")->encode();
        }

    }
}catch(Exception $e){
    echo 'Exceção capturada: ',  $e->getMessage(), "\n";
}

?>
