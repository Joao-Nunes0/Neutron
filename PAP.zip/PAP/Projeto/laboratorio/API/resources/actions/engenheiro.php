<?php

function fileUploaded()
{
    if(empty($_FILES)) {
        return false;
    }
    return true;
}

try{
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (isset($_SESSION['control'])) {
      
    }
}catch (Exception $e)
  {
      echo 'Exceção capturada: ',  $e->getMessage(), "\n";
  }
?>
