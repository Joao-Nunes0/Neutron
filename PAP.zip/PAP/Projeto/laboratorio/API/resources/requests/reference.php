<?php //PERFORMAR TODAS AS AÇÕES RELACIONADAS A AUTENTICAÇÃO
require 'resources/classes/references.php' ;
if(session_status() !== PHP_SESSION_ACTIVE) session_start();
if (isset($_SESSION['control'])) { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.

  $sql = mysqli_query($conn,"SELECT * FROM equipament,clients,relations WHERE relations.id_wkr is null AND relations.id_eqp = equipament.id_eqp AND relations.id_client = clients.id_client ORDER BY equipament.date_reception_eqp;");
  $data = array();
  while ($row = mysqli_fetch_array($sql)){
    $data[] = new Order($row['id_eqp'],
    $row['id_client'],
    $row['brand_eqp'],
    $row['model_eqp'],
    $row['seriesnum_eqp'],
    $row['date_reception_eqp'],
    $row['simptons_eqp'],
    $row['state_eqp']);
  }
  echo (new Message(true, $data))->encode();

}
