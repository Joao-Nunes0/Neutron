<?php //PERFORMAR TODAS AS AÇÕES RELACIONADAS A AUTENTICAÇÃO
require 'resources/classes/clients.php' ;
if(session_status() !== PHP_SESSION_ACTIVE) session_start();
if (isset($_SESSION['control'])) { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.

  $sql = mysqli_query($conn,"SELECT * FROM clients");
  $data = array();
  while ($row = mysqli_fetch_array($sql)){
    $data[] = new Order($row['id_client'],
    $row['name_client'],
    $row['nif_client'],
    $row['email_client'],
    $row['phone_client'],
    $row['address_client']);
  }
  echo (new Message(true, $data))->encode();

}
