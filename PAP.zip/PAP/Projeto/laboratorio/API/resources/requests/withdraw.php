<?php //PERFORMAR TODAS AS AÇÕES RELACIONADAS A AUTENTICAÇÃO
require 'resources/classes/withdraws.php' ;
if(session_status() !== PHP_SESSION_ACTIVE) session_start();
if (isset($_SESSION['control'])) { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.

  $sql = mysqli_query($conn,"SELECT * FROM equipament,clients,relations WHERE status_eqp = 'Retirar' AND relations.id_eqp = equipament.id_eqp AND relations.id_client = clients.id_client ORDER BY equipament.date_reception_eqp");
  $data = array();
  while ($row = mysqli_fetch_array($sql)){
    $sql2 = "SELECT DISTINCT name_client FROM clients,relations,equipament WHERE equipament.id_eqp = ".$row['id_eqp']." AND equipament.id_eqp = relations.id_eqp AND clients.id_client = relations.id_client";
    $result = mysqli_query($conn,$sql2);
    $row2 = mysqli_fetch_array($result);
    $data[] = new Order($row['id_eqp'],
    $row['id_client'],
    $row2['name_client'],
    $row['brand_eqp'],
    $row['model_eqp'],
    $row['seriesnum_eqp'],
    $row['date_reception_eqp'],
    $row['simptons_eqp'],
    $row['state_eqp']);
  }
  echo (new Message(true, $data))->encode();

}
