<?php //PERFORMAR TODAS AS AÇÕES RELACIONADAS A AUTENTICAÇÃO
require 'resources/classes/workers.php' ;
if(session_status() !== PHP_SESSION_ACTIVE) session_start();
if (isset($_SESSION['control'])) { //$_SESSION['control'] evita que o cliente aceda aos ficheiros da API.

  $sql = mysqli_query($conn,"SELECT * FROM workers");
  $data = array();
  while ($row = mysqli_fetch_array($sql)){
    $data[] = new Order($row['id_wkr'],
    $row['name_wkr'],
    $row['email_wkr'],
    $row['role_wkr'],
    $row['phone_wkr']);
  }
  echo (new Message(true, $data))->encode();

}
