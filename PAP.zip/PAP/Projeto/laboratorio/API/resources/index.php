<?php
header ('Location: ../');
?>